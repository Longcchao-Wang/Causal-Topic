#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
causal_gnn.py – Lightweight GNN over a (fixed) causal DAG

"""

from __future__ import annotations
from typing import Union, Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# --------------------------------------------------------------------------- #
# helper
# --------------------------------------------------------------------------- #
def _row_norm(M: torch.Tensor) -> torch.Tensor:
    """Row-normalise矩阵，避免除零。"""
    return M / (M.sum(1, keepdim=True) + 1e-8)


# --------------------------------------------------------------------------- #
# main class
# --------------------------------------------------------------------------- #
class CausalGNN(nn.Module):
    r"""GNN that propagates messages **only along causal edges** j → i."""

    def __init__(
        self,
        A: Union[np.ndarray, torch.Tensor],
        in_dim: int,
        hid: int | None = None,
        layers: int = 2,
        dropout: float = 0.0,
        resid: bool = False,
        device: str | torch.device | None = None,
    ) -> None:
        super().__init__()

        self.device = (
            torch.device(device)
            if device is not None
            else torch.device("cuda" if torch.cuda.is_available() else "cpu")
        )

        # -------- fixed adjacency (row-norm) --------
        if not torch.is_tensor(A):
            A = torch.tensor(A, dtype=torch.float32)
        if A.ndim != 2 or A.size(0) != A.size(1):
            raise ValueError("A must be a square (N,N) matrix.")
        A = _row_norm(A)
        self.register_buffer("A", A.to(self.device))
        self.N = A.size(0)

        # -------- layers --------
        hid = hid or in_dim
        self.in_proj = nn.Identity() if in_dim == hid else nn.Linear(in_dim, hid, bias=False)
        self.self_w = nn.ModuleList(nn.Linear(hid, hid, bias=False) for _ in range(layers))
        self.par_w = nn.ModuleList(nn.Linear(hid, hid, bias=False) for _ in range(layers))
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.act = nn.ReLU()
        self.resid = resid
        self.L = layers

    # -------------------- factory: build from cluster --------------------
    @classmethod
    def from_cluster(
        cls,
        cluster: Sequence[int],
        in_dim: int,
        hid: int | None = None,
        layers: int = 2,
        dropout: float = 0.0,
        resid: bool = False,
        device: str | torch.device | None = None,
    ) -> "CausalGNN":
        """
        给定每个节点所属簇 (length N) -> 构造 “簇间全连接” DAG：
        若 cluster[i] != cluster[j] 则视作 i→j （父簇→子簇），同簇内不连边。
        """
        cluster = torch.as_tensor(cluster, dtype=torch.long)
        N = cluster.size(0)
        A = torch.zeros(N, N)
        idx = torch.arange(N)
        for i in idx:
            dst = idx[cluster != cluster[i]]  # 不同簇
            A[dst, i] = 1.0                  # dst → i
        return cls(A, in_dim, hid, layers, dropout, resid, device)

    # ------------------------------------------------------------------ #
    def forward(self, h: torch.Tensor) -> torch.Tensor:
        """
        h : (N,F) or (B,N,F)  node features
        return: same shape
        """
        if h.device != self.device:
            h = h.to(self.device)

        batchless = h.dim() == 2
        if batchless:
            h = h.unsqueeze(0)

        h = self.in_proj(h)
        for ℓ in range(self.L):
            par_msg = torch.einsum("ij,bjf->bif", self.A.t(), h)  # parents → child
            x = self.self_w[ℓ](h) + self.par_w[ℓ](par_msg)
            h_next = self.act(x)
            h_next = self.dropout(h_next)
            if self.resid:
                h = h + h_next
            else:
                h = h_next

        return h.squeeze(0) if batchless else h

    # ------------------------------------------------------------------ #
    def forward_and_pool(self, h: torch.Tensor, pool: str = "mean") -> torch.Tensor:
        """Encode then pool to graph-level vector."""
        h = self.forward(h)  # (B,N,H) / (N,H)
        if h.dim() == 2:  # (N,H)
            return h.mean(0) if pool == "mean" else h.max(0).values
        if pool == "mean":
            return h.mean(1)
        if pool == "max":
            return h.max(1).values
        raise ValueError(f"Unsupported pool type: {pool}")
