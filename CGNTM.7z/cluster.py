#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
cluster_builder.py  —  从因果邻接矩阵生成层级聚类文件
"""
from __future__ import annotations

import logging
import json
from itertools import combinations
from pathlib import Path

import numpy as np
import networkx as nx
from sklearn.cluster import KMeans
from sklearn.preprocessing import normalize
from tqdm import tqdm


# --------------------------------------------------------------------------- #
#                               日志工具                                      #
# --------------------------------------------------------------------------- #
def get_logger(name: str = __name__) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
        logger.addHandler(h)
    return logger


logger = get_logger()


# --------------------------------------------------------------------------- #
#                             DAG 工具函数                                    #
# --------------------------------------------------------------------------- #
def is_dag(adj: np.ndarray, thresh: float = 1e-9) -> bool:
    """判断加权邻接矩阵是否 DAG；小于 thresh 视为无边。"""
    G = nx.from_numpy_array(adj > thresh, create_using=nx.DiGraph)
    return nx.is_directed_acyclic_graph(G)


def greedy_prune_cycles(A: np.ndarray) -> np.ndarray:
    """贪心删除最小权重边直到形成 DAG。"""
    G = nx.from_numpy_array(A, create_using=nx.DiGraph)
    for u, v, d in G.edges(data=True):
        d["w"] = A[u, v]

    while not nx.is_directed_acyclic_graph(G):
        cycle = next(nx.simple_cycles(G))
        # 找到环上权最小的边
        min_edge = min(
            ((cycle[i], cycle[(i + 1) % len(cycle)]) for i in range(len(cycle))),
            key=lambda e: G[e[0]][e[1]]["w"],
        )
        logger.debug("Break cycle %s by removing edge %s", cycle, min_edge)
        G.remove_edge(*min_edge)

    # 回写矩阵
    n = G.number_of_nodes()
    A_dag = np.zeros((n, n), dtype=np.float32)
    for u, v, d in G.edges(data=True):
        A_dag[u, v] = d["w"]
    return A_dag


# --------------------------------------------------------------------------- #
#                           聚类主函数                                        #
# --------------------------------------------------------------------------- #
def build_clustering_file(
    A: np.ndarray,
    node_names: list[str],
    n_clusters: int = 5,
    out_dir: Path | str = "生物医学因果主题发现/CGNTM/data",
) -> np.ndarray:
    """
    生成 cluster_ids.npy 和 cluster_info.json 并返回 cluster_labels

    Parameters
    ----------
    A : np.ndarray
        (N,N) 的因果邻接矩阵 (已是 DAG)。
    node_names : list[str]
        节点名称，与 A 顺序一致。
    n_clusters : int
        聚类簇数 (≤N)；自动纠正过大/过小值。
    out_dir : Path | str
        保存输出文件的目录。
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ★ 1) 组合出边 + 入边特征，并 L1 归一化
    X = np.hstack([A, A.T]).astype(np.float32)
    X = normalize(X, norm="l1", axis=1)

    # ★ 2) 修正簇数范围
    n_nodes = X.shape[0]
    n_clusters = max(2, min(n_clusters, n_nodes))

    logger.info("KMeans clustering: N=%d, k=%d …", n_nodes, n_clusters)
    kmeans = KMeans(
        n_clusters=n_clusters,
        random_state=42,
        n_init="auto",
    )
    cluster_labels = kmeans.fit_predict(X)

    # ★ 3) 保存结果
    np.save(out_dir / "cluster_ids.npy", cluster_labels)
    with (out_dir / "cluster_info.json").open("w", encoding="utf-8") as f:
        json.dump(
            {"node_names": node_names, "cluster_labels": cluster_labels.tolist()},
            f,
            ensure_ascii=False,
            indent=2,
        )
    logger.info("Saved cluster_ids.npy & cluster_info.json to %s", out_dir)
    return cluster_labels


# --------------------------------------------------------------------------- #
#                                CLI                                          #
# --------------------------------------------------------------------------- #
def parse_args():
    import argparse

    ap = argparse.ArgumentParser("Build clustering file for HierarchicalGNN")
    ap.add_argument("--data_dir", default="生物医学因果主题发现/CGNTM/data")
    ap.add_argument(
        "-k", "--k", type=int, default=5, help="number of clusters (default 5)"
    )
    ap.add_argument(
        "--prune",
        action="store_true",
        help="若 causal_graph 可能含环，则先贪心断环保证 DAG",
    )
    return ap.parse_args()


def main():
    args = parse_args()
    data_dir = Path(args.data_dir)

    # 读取数据
    node_names = json.load(open(data_dir / "node_names.json", encoding="utf-8"))
    A = np.load(data_dir / "causal_graph.npy")

    # 保证 DAG
    if not is_dag(A):
        if args.prune:
            logger.warning("Graph contains cycles – pruning …")
            A = greedy_prune_cycles(A)
            np.save(data_dir / "causal_graph_dag.npy", A)
            logger.info("Saved pruned DAG to causal_graph_dag.npy")
        else:
            raise RuntimeError(
                "Adjacency matrix has cycles; use --prune or修正原图后再运行。"
            )

    build_clustering_file(A, node_names, n_clusters=args.k, out_dir=data_dir)


if __name__ == "__main__":
    main()
