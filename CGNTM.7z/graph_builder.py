#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
graph_builder_fixed.py — Build biomedical causal **DAG** from LLM-extracted `causal_relations`.
"""
from __future__ import annotations
import argparse, json, logging, random, subprocess, sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple
import os
import matplotlib
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from tqdm import tqdm


# -----------------------------------------------------------------------------
# 实用函数
# -----------------------------------------------------------------------------
def seed_all(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)


def get_logger(name: str = __name__) -> logging.Logger:
    lg = logging.getLogger(name)
    if not lg.handlers:
        lg.setLevel(logging.INFO)
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
        lg.addHandler(h)
    return lg


logger = get_logger()

# -----------------------------------------------------------------------------
# DAG helpers
# -----------------------------------------------------------------------------
def is_dag(adj: np.ndarray, thresh: float = 1e-9) -> bool:
    G = nx.from_numpy_array(adj > thresh, create_using=nx.DiGraph)
    return nx.is_directed_acyclic_graph(G)


def greedy_prune_cycles(A: np.ndarray) -> np.ndarray:
    G = nx.from_numpy_array(A, create_using=nx.DiGraph)
    for u, v, d in G.edges(data=True):
        d["w"] = A[u, v]

    while not nx.is_directed_acyclic_graph(G):
        cycle = next(nx.simple_cycles(G))
        min_edge = min(
            ((cycle[i], cycle[(i + 1) % len(cycle)]) for i in range(len(cycle))),
            key=lambda e: G[e[0]][e[1]]["w"],
        )
        logger.debug("break cycle %s by removing edge %s", cycle, min_edge)
        G.remove_edge(*min_edge)

    A_dag = np.zeros_like(A, dtype=np.float32)
    for u, v, d in G.edges(data=True):
        A_dag[u, v] = d["w"]
    return A_dag


# -----------------------------------------------------------------------------
# 主流程：triplets → DAG
# -----------------------------------------------------------------------------
def build_graph(
    triplet_path: Path,
    min_freq: int = 1,
    weight_threshold: float = 0.05,
) -> Tuple[List[str], np.ndarray]:
    logger.info("📖 读取因果三元组: %s", triplet_path)
    data = json.loads(triplet_path.read_text(encoding="utf-8"))

    edge_counts: Dict[Tuple[str, str], int] = defaultdict(int)
    node_set: set[str] = set()

    for entry in tqdm(data, desc="Scanning triplets"):
        for rel in entry.get("causal_relations", []):
            c = str(rel.get("cause", "")).strip().lower()
            e = str(rel.get("effect", "")).strip().lower()
            if c and e and c != e:
                node_set.update([c, e])
                edge_counts[(c, e)] += 1

    node_names = sorted(node_set)
    node2idx = {n: i for i, n in enumerate(node_names)}
    n = len(node_names)
    logger.info("节点数: %d", n)

    A = np.zeros((n, n), dtype=np.float32)
    for (c, e), cnt in edge_counts.items():
        if cnt >= min_freq:
            i, j = node2idx[c], node2idx[e]
            A[i, j] = cnt

    logger.info("原始保留边数: %d", int((A > 0).sum()))

    if A.max() > 0:
        A /= A.max()

    if not is_dag(A):
        logger.info("检测到环路，开始贪心断环…")
        A = greedy_prune_cycles(A)
        logger.info("图已为 DAG。")
    else:
        logger.info("图已为 DAG，无需断环。")

    A[A < weight_threshold] = 0.0
    logger.info("最终保留边数 (>%.2f): %d", weight_threshold, int((A > 0).sum()))
    return node_names, A


# -----------------------------------------------------------------------------
# 导出工具
# -----------------------------------------------------------------------------
def visualize_dag(A: np.ndarray, node_names: List[str], top_k: int, save_path: Path):
    if not os.environ.get("DISPLAY"):
        matplotlib.use("Agg")

    G = nx.from_numpy_array(A > 0, create_using=nx.DiGraph)
    degrees = dict(G.degree())
    top_nodes = sorted(degrees, key=degrees.get, reverse=True)[:top_k]
    subG = G.subgraph(top_nodes)
    mapping = {i: node_names[i] for i in subG.nodes}
    subG = nx.relabel_nodes(subG, mapping)

    plt.figure(figsize=(12, 8))
    pos = nx.spring_layout(subG, k=0.6, seed=42)
    nx.draw_networkx(
        subG,
        pos,
        node_size=800,
        node_color="skyblue",
        font_size=9,
        edge_color="gray",
        arrows=True,
        width=1.2,
    )
    plt.title(f"Top-{top_k} causal relations")
    save_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close()
    logger.info("已保存子图到 %s", save_path)


def export_for_gephi(A: np.ndarray, node_names: List[str], out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    with (out_dir / "edges.tsv").open("w", encoding="utf-8") as f:
        for i, j in zip(*np.nonzero(A)):
            f.write(f"{node_names[i]}\t{node_names[j]}\t{A[i, j]:.6f}\n")
    with (out_dir / "nodes.tsv").open("w", encoding="utf-8") as f:
        for n in node_names:
            f.write(f"{n}\n")
    logger.info("Gephi 文件已导出到 %s", out_dir)


def export_pred_edges(A: np.ndarray, node_names: List[str], path: Path):
    """导出预测因果边 head<TAB>tail，供评估 CP/RCR 使用"""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for i, j in zip(*np.nonzero(A)):
            f.write(f"{node_names[i]}\t{node_names[j]}\n")
    logger.info("pred_edges.txt 已写入 %s", path)


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser("Build deterministic causal DAG")
    p.add_argument("--root_dir", default="生物医学因果主题发现/CGNTM")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--min_freq", type=int, default=1)
    p.add_argument("--weight_threshold", type=float, default=0.05)
    p.add_argument("--top_k", type=int, default=30)
    # 新增
    p.add_argument("--export_edges", default="", help="自定义 pred_edges.txt 路径")
    p.add_argument("--build_cluster", action="store_true",
                   help="生成 cluster_ids.npy (调用 cluster_builder.py)")
    p.add_argument("--k_cluster", type=int, default=6, help="KMeans 簇数 (配合 --build_cluster)")
    return p.parse_args()


def main():
    args = parse_args()
    seed_all(args.seed)

    root = Path(args.root_dir)
    data_dir = root / "data"
    figures_dir = root / "figures"
    output_dir = root / "output" / "graph"
    eval_dir = root / "eval"

    for d in [data_dir, figures_dir, output_dir, eval_dir]:
        d.mkdir(parents=True, exist_ok=True)

    triplet_path = data_dir / "pub_causal_triplets.json"
    if not triplet_path.exists():
        logger.error("未找到 %s，请先运行 llm_extraction.py", triplet_path)
        sys.exit(1)

    node_names, A_dag = build_graph(
        triplet_path, min_freq=args.min_freq, weight_threshold=args.weight_threshold
    )

    # 保存
    np.save(data_dir / "causal_graph.npy", A_dag)
    json.dump(node_names, open(data_dir / "node_names.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    logger.info("✅ 保存 causal_graph.npy & node_names.json 到 %s", data_dir)

    # 导出预测边
    pred_edge_path = Path(args.export_edges) if args.export_edges else eval_dir / "pred_edges.txt"
    export_pred_edges(A_dag, node_names, pred_edge_path)

    # Gephi
    export_for_gephi(A_dag, node_names, output_dir)

    # 可视化
    visualize_dag(A_dag, node_names, args.top_k, figures_dir / "causal_graph_topk.png")

    # 可选：自动构建 cluster_ids.npy
    if args.build_cluster:
        cluster_builder = Path(__file__).parent / "cluster_builder.py"
        if not cluster_builder.exists():
            logger.error("未找到 cluster_builder.py，无法生成簇信息。")
        else:
            cmd = [sys.executable, str(cluster_builder),
                   "--data_dir", str(data_dir),
                   "-k", str(args.k_cluster)]
            subprocess.run(cmd, check=True)
            logger.info("✅ cluster_ids.npy 生成完毕。")

    logger.info("🎉 任务完成！")


if __name__ == "__main__":
    main()
