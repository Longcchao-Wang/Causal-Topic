import pandas as pd
import re
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm


def clean_text(text):
    """清洗文本：移除中文字符和web代码标识"""
    if not isinstance(text, str):
        return ""
    # 移除中文字符（包括CJK统一汉字和扩展区）
    text = re.sub(r'[\u4e00-\u9fa5\u3400-\u4dbf\U00020000-\U0002a6df]', '', text)

    # 移除HTML标签
    text = re.sub(r'<[^>]+>', '', text)

    # 移除URL链接
    text = re.sub(r'https?://\S+|www\.\S+', '', text)

    # 移除HTML实体（如&nbsp;,&amp;等）
    text = re.sub(r'&\w+;', ' ', text)

    # 移除JavaScript事件（如onclick,onload等）
    text = re.sub(r'on\w+="[^"]*"', '', text)

    # 移除style属性
    text = re.sub(r'style="[^"]*"', '', text)

    # 移除多余空格和特殊符号
    text = re.sub(r'[^\w\s.,!?\-\(\)]', ' ', text)

    # 合并多个空格为一个
    text = re.sub(r'\s+', ' ', text).strip()

    return text


def is_valid_year(year):
    """判断是否为有效的年份"""
    try:
        year_int = int(year)
        return 1800 <= year_int <= 2100  # 合理年份范围
    except (ValueError, TypeError):
        return False


def is_english_text(text):
    """判断是否为以英文为主的文本"""
    if not isinstance(text, str) or len(text.strip()) == 0:
        return False
    # 统计英文字符比例
    english_chars = re.findall(r'[a-zA-Z]', text)
    total_chars = len(text)
    if total_chars == 0:
        return False
    english_ratio = len(english_chars) / total_chars
    return english_ratio > 0.7  # 要求英文字符占比超过70%


def parallel_apply(func, series, desc="Processing"):
    """
    对 pandas.Series 并行执行函数，并显示进度条
    """
    data = series.tolist()
    results = []
    with ProcessPoolExecutor() as executor:
        future_to_index = {executor.submit(func, item): i for i, item in enumerate(data)}
        for future in tqdm(as_completed(future_to_index), total=len(data), desc=desc):
            index = future_to_index[future]
            try:
                result = future.result()
                results.append((index, result))
            except Exception as e:
                print(f"Error processing item: {e}")
    # 按照原始顺序恢复结果
    results.sort(key=lambda x: x[0])
    return [r[1] for r in results]


def process_biomedical_data(input_path, output_path):
    """处理生物医学文献数据，并行清洗 Title 和 Abstract 字段"""
    try:
        # 自动尝试不同编码读取文件
        encodings = ['utf-8', 'gbk', 'latin1']
        df = None
        for encoding in encodings:
            try:
                with tqdm(total=1, desc=f"尝试用 {encoding} 编码读取文件") as pbar:
                    df = pd.read_csv(input_path, encoding=encoding)
                    pbar.update(1)
                print(f"成功使用 {encoding} 编码读取文件")
                break
            except UnicodeDecodeError:
                continue
        if df is None:
            raise Exception("无法读取文件，请检查编码格式")

        # 保留指定列
        columns_to_keep = ['PMID', 'Title', 'Abstract', 'Year']
        df = df[columns_to_keep]
        tqdm.write("✅ 已保留指定列")

        # 删除含空值的行
        with tqdm(total=1, desc="删除包含空值的行") as pbar:
            df.dropna(subset=columns_to_keep, inplace=True)
            pbar.update(1)

        # 并行清洗 Title 和 Abstract
        print("🔍 开始清洗字段...")
        cleaned_titles = parallel_apply(clean_text, df['Title'], desc="清洗 Title 字段")
        cleaned_abstracts = parallel_apply(clean_text, df['Abstract'], desc="清洗 Abstract 字段")

        # 更新 DataFrame
        with tqdm(total=1, desc="更新清洗后的字段") as pbar:
            df['Title'] = cleaned_titles
            df['Abstract'] = cleaned_abstracts
            pbar.update(1)

        # 过滤掉清洗后为空的行
        with tqdm(total=1, desc="初步过滤空字段") as pbar:
            df = df[(df['Title'].str.strip() != '') & (df['Abstract'].str.strip() != '')]
            pbar.update(1)

        # 再次严格过滤：确保 Year 是有效年份，且 Title 和 Abstract 是英文
        print("🔍 开始严格校验字段内容...")
        valid_rows = []

        for idx, row in tqdm(df.iterrows(), total=len(df), desc="严格校验字段内容"):
            valid_year = is_valid_year(row['Year'])
            valid_title = is_english_text(row['Title'])
            valid_abstract = is_english_text(row['Abstract'])

            if valid_year and valid_title and valid_abstract:
                valid_rows.append(True)
            else:
                valid_rows.append(False)

        df = df[valid_rows]

        # 保存结果
        with tqdm(total=1, desc="保存处理结果") as pbar:
            df.to_csv(output_path, index=False, encoding='utf-8')
            pbar.update(1)

        print(f"\n✅ 数据处理完成，已保存至 {output_path}")
        print(f"📊 共处理 {len(df)} 条记录")

        return df

    except Exception as e:
        print(f"❌ 处理过程中出现错误: {e}")
        return None


# 示例运行
if __name__ == '__main__':
    input_file = "生物医学因果主题发现/CGNTM/data/pub_肺癌.csv"
    output_file = "生物医学因果主题发现/CGNTM/data/pub.csv"

    processed_df = process_biomedical_data(input_file, output_file)