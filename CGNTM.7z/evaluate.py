#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
evaluate.py – 干预影响可视化 + CGNTM 五项指标计算-
# 计算论文指标并保存报告
$ python evaluate.py --root_dir 生物医学因果主题发现/CGNTM --metrics --report metrics.json
"""
from __future__ import annotations
import argparse, json, os, math, logging
from pathlib import Path
from typing import List, Tuple

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.metrics.pairwise import cosine_similarity

from hierarchical_gnn import HierarchicalGNN          # :contentReference[oaicite:1]{index=1}

# ----------------------------- 日志 ----------------------------- #
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s - %(levelname)s - %(message)s")
log = logging.getLogger("evaluate")


# --------------------------- 基础工具 --------------------------- #
def get_device(gpu: bool = False) -> torch.device:
    return torch.device("cuda" if gpu and torch.cuda.is_available() else "cpu")


# --------------------------- 论文指标 --------------------------- #
def build_counts(corpus_path: Path):
    """词频 & 共现统计（同一行视为同文档）"""
    from collections import Counter
    from itertools import combinations
    w_cnt, co_cnt = Counter(), Counter()
    total = 0
    with corpus_path.open(encoding="utf-8") as f:
        for line in f:
            total += 1
            ws = list(dict.fromkeys(line.strip().split()))
            w_cnt.update(ws)
            for w1, w2 in combinations(ws, 2):
                if w1 != w2:
                    co_cnt[tuple(sorted((w1, w2)))] += 1
    return w_cnt, co_cnt, total


def compute_npmi(top_words: List[List[str]],
                 co_cnt, w_cnt, total_docs: int, eps=1e-12) -> float:
    scores = []
    for topic in top_words:
        if len(topic) < 2:
            continue
        s, valid = 0.0, 0
        for i, w1 in enumerate(topic):
            for w2 in topic[i + 1:]:
                pair = tuple(sorted((w1, w2)))
                c_xy = co_cnt.get(pair, 0)
                if c_xy == 0:
                    continue
                p_xy = c_xy / total_docs
                p_x, p_y = w_cnt[w1] / total_docs, w_cnt[w2] / total_docs
                pmi = math.log(max(p_xy, eps) / (p_x * p_y + eps))
                npmi = pmi / (-math.log(p_xy + eps))
                s += npmi
                valid += 1
        if valid:
            scores.append(s / valid)
    return float(np.mean(scores)) if scores else 0.0


def compute_td(top_words: List[List[str]]) -> float:
    all_words = [w for topic in top_words for w in topic]
    return len(set(all_words)) / len(all_words) if all_words else 0.0


def load_edges(path: Path) -> List[Tuple[str, str]]:
    edges = []
    with path.open(encoding="utf-8") as f:
        for ln in f:
            parts = ln.strip().split("\t")
            if len(parts) == 2:
                edges.append(tuple(parts))
    return edges


def compute_cp_rcr(pred_edges, true_edges):
    if not pred_edges:
        return 0.0, 0.0
    tp = sum((h, t) in true_edges for h, t in pred_edges)
    rev = sum((t, h) in true_edges for h, t in pred_edges)
    return tp / len(pred_edges), rev / len(pred_edges)


def compute_csa(orig_emb: np.ndarray, cf_emb: np.ndarray) -> float:
    sims = cosine_similarity(orig_emb, cf_emb)
    return float(np.diag(sims).mean())


# ------------------------ 干预工具函数 --------------------------- #
@torch.no_grad()
def simulate_intervention(model: HierarchicalGNN,
                          n_nodes: int,
                          target_idx: int,
                          device: torch.device) -> np.ndarray:
    """
    do(X_target=0) 干预：设目标节点特征=0，其他=1
    返回 Δ‖z‖₂
    """
    x_base = torch.ones(n_nodes, 1, device=device)
    z0 = model(x_base).float()
    x_base[target_idx, 0] = 0.0
    z1 = model(x_base).float()
    delta = (z0 - z1).norm(p=2, dim=-1)  # (N,)
    return delta.cpu().numpy()


# ------------------------------ CLI ------------------------------ #
def parse_args():
    p = argparse.ArgumentParser("CGNTM Evaluation")
    p.add_argument("--root_dir", default="生物医学因果主题发现/CGNTM")
    p.add_argument("--target", default="cigarette smoking")
    p.add_argument("--topk", type=int, default=15)
    p.add_argument("--gpu", action="store_true")
    p.add_argument("--save", type=str, default="")
    p.add_argument("--metrics", action="store_true",
                   help="同时计算 NPMI/TD/CP/RCR/CSA")
    p.add_argument("--report", type=str, default="",
                   help="若指定则将指标写入 JSON")
    return p.parse_args()


# ================================================================ #
def main():
    args = parse_args()
    root = Path(args.root_dir)
    data_dir = root / "data"

    # -------- assets --------
    A = np.load(data_dir / "causal_graph.npy")
    node_names: List[str] = json.load(open(data_dir / "node_names.json"))
    cluster_path = data_dir / "cluster_ids.npy"
    cluster = np.load(cluster_path) if cluster_path.exists() else None

    # -------- model --------
    dev = get_device(args.gpu)
    model = HierarchicalGNN(A, in_dim=1,
                            cluster=cluster,
                            hid=64,
                            device=dev).to(dev)
    p_hgnn = root / "models/hgnn_joint.pth"
    if p_hgnn.exists():
        model.load_state_dict(torch.load(p_hgnn, map_location=dev))
        log.info("Loaded HGNN weights.")
    model.eval()

    # -------- simulate do() --------
    if args.target not in node_names:
        raise ValueError(f"target '{args.target}' not in node list.")
    idx_tgt = node_names.index(args.target)
    influence = simulate_intervention(model, len(node_names), idx_tgt, dev)

    # -------- plot top-k --------
    order = np.argsort(-influence)
    order = order[order != idx_tgt][: args.topk]

    if not os.environ.get("DISPLAY") and args.save == "":
        matplotlib.use("Agg")

    plt.figure(figsize=(8, 6))
    bars = influence[order][::-1]
    labels = [node_names[i] for i in order][::-1]
    plt.barh(range(len(bars)), bars)
    plt.yticks(range(len(bars)), labels)
    plt.xlabel("Intervention Effect (‖Δz‖₂)")
    plt.title(f"Top {args.topk} nodes influenced by do({args.target}=0)")
    plt.tight_layout()

    if args.save or not os.environ.get("DISPLAY"):
        out_img = args.save or (root / f"fig_intervene_{args.target}.png")
        plt.savefig(out_img, dpi=300)
        log.info("Figure saved to %s", out_img)
    else:
        plt.show()

    # -------------------------------------------------------------- #
    #                     论文指标 (可选)                            #
    # -------------------------------------------------------------- #
    if args.metrics:
        eval_dir = root / "eval"
        # ---- files sanity ----
        required = ["corpus.txt", "topic_words.json",
                    "pred_edges.txt", "true_edges.txt",
                    "embeddings.npz"]
        for f in required:
            if not (eval_dir / f).exists():
                raise FileNotFoundError(f"{eval_dir/f} not found – 指标无法计算。")

        # ---- load data ----
        topic_words = json.load(open(eval_dir / "topic_words.json"))
        w_cnt, co_cnt, total = build_counts(eval_dir / "corpus.txt")
        pred_edges = load_edges(eval_dir / "pred_edges.txt")
        true_edges = set(load_edges(eval_dir / "true_edges.txt"))
        emb = np.load(eval_dir / "embeddings.npz")
        orig_emb, cf_emb = emb["orig"], emb["cf"]

        # ---- compute ----
        npmi = compute_npmi(topic_words, co_cnt, w_cnt, total)
        td = compute_td(topic_words)
        cp, rcr = compute_cp_rcr(pred_edges, true_edges)
        csa = compute_csa(orig_emb, cf_emb)

        metrics = {
            "NPMI": round(npmi, 4),
            "TD": round(td, 4),
            "CP": round(cp, 4),
            "RCR": round(rcr, 4),
            "CSA": round(csa, 4),
        }
        print(json.dumps(metrics, indent=2, ensure_ascii=False))

        if args.report:
            Path(args.report).write_text(json.dumps(metrics, indent=2,
                                                    ensure_ascii=False))
            log.info("Metrics saved to %s", args.report)


if __name__ == "__main__":
    main()
