#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
wgan_generator.py – Text generator used as *G* in WGAN stage
"""
from __future__ import annotations
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class WGANGenerator(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        topic_dim: int,
        emb_dim: int = 128,
        noise_dim: int = 100,
        hid: int = 128,                  # ⬅ 将默认 hid 调成与 emb_dim 一致，避免维度错配
        pad_id: int = 0,
        bos_id: int = 1,
        eos_id: int = 2,
        share_emb_out: bool = False,
    ) -> None:
        super().__init__()
        self.V = vocab_size
        self.emb_dim = emb_dim                    # ★ 外部可读取
        self.noise_dim = noise_dim
        self.pad_id, self.bos_id, self.eos_id = pad_id, bos_id, eos_id

        # ------------------ Embedding ------------------ #
        self.emb = nn.Embedding(self.V, emb_dim, padding_idx=self.pad_id)

        # ------------------ Generator core ------------- #
        self.gru  = nn.GRUCell(emb_dim, hid)
        self.init = nn.Linear(topic_dim + noise_dim, hid)

        # ------------------ Output projection ---------- #
        if share_emb_out and hid != emb_dim:
            raise ValueError(
                f"share_emb_out=True 要求 hid==emb_dim，但当前 hid={hid}, emb_dim={emb_dim}"
            )
        self.out = nn.Linear(hid, self.V, bias=False)  # (B,hid) → (B,V)

        # 权重共享（可选）
        if share_emb_out:
            self.out.weight = self.emb.weight  # type: ignore[assignment]

        # <pad> 行置零并冻结
        with torch.no_grad():
            self.emb.weight[self.pad_id].zero_()

    # ------------------------------------------------------------------ #
    @torch.inference_mode(False)
    def forward(
        self,
        topic_z: torch.Tensor,                     # (B, topic_dim)
        max_len: int = 30,
        tau: float = 1.0,
        greedy: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate hard token ids  &  their effective lengths."""

        B, dev = topic_z.size(0), topic_z.device
        noise = torch.randn(B, self.noise_dim, device=dev)
        h = self.init(torch.cat([topic_z, noise], dim=1))     # (B,hid)

        x = self.emb(torch.full((B,), self.bos_id, dtype=torch.long, device=dev))
        tokens  = torch.full((B, max_len), self.pad_id, dtype=torch.long, device=dev)
        lengths = torch.zeros(B, dtype=torch.long, device=dev)
        ended   = torch.zeros(B, dtype=torch.bool, device=dev)

        for t in range(max_len):
            h = self.gru(x, h)             # (B,hid)
            logits = self.out(h)           # (B,V)

            if greedy or tau == 0:         # argmax
                idx = logits.argmax(1)
                x   = self.emb(idx)
            else:                          # Gumbel-Softmax
                y   = F.gumbel_softmax(logits, tau=tau, hard=True)
                idx = y.argmax(1)
                x   = y @ self.emb.weight

            tokens[:, t] = idx

            new_end = idx.eq(self.eos_id) & (~ended)
            lengths[new_end] = t + 1
            ended |= new_end
            if ended.all():
                break

        # 对仍未结束的行，长度记满
        lengths[lengths == 0] = max_len

        # 保证 <pad> 行始终为零
        with torch.no_grad():
            self.emb.weight[self.pad_id].zero_()

        return tokens, lengths
