import os
import re
import time
import json
import logging
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
import pandas as pd
from openai import OpenAI
import numpy as np

# ---------------------- 配置参数 ----------------------
# 日志设置
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# DeepSeek API 设置
client = OpenAI(
    api_key="sk-xxxxxxxxxxxxxxxxxxxxxxxxxxx",  # 替换为你自己的 API Key
    base_url="https://api.deepseek.com"  # 注意确保 URL 正确
)
'''
client = OpenAI(
    api_key="sk-xxxxxxxxxxxxxxxxxxxxxxxxxx",  # 替换为你自己的 API Key
    base_url="http://10.33.5.141:11434/v1"  # 注意确保 URL 正确
)
'''
# 输入输出路径
INPUT_CSV_PATH = "生物医学因果主题发现/CGNTM/data/pub.csv"
OUTPUT_JSON_PATH = "生物医学因果主题发现/CGNTM/data/pub_causal_triplets.json"

# ---------------------- 自定义 JSON Encoder ----------------------

class NpEncoder(json.JSONEncoder):
    """用于支持 numpy 数据类型的 JSON 编码器"""
    def default(self, obj):
        if isinstance(obj, (np.int64, np.int32)):
            return int(obj)
        elif isinstance(obj, (np.float64, np.float32)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, pd.Series):
            return obj.tolist()
        elif isinstance(obj, pd.DataFrame):
            return obj.to_dict(orient='records')
        else:
            return super().default(obj)

# ---------------------- 数据处理函数 ----------------------

def clean_data(df):
    """清洗数据：去除空值"""
    df = df[df["PMID"].astype(str).str.strip().ne("")]
    df = df[df["Title"].astype(str).str.strip().ne("")]
    df = df[df["Abstract"].astype(str).str.strip().ne("")]
    return df.reset_index(drop=True)

def extract_text(row):
    """拼接标题与摘要"""
    return f"TITLE: {row.get('Title', '')}\nABSTRACT: {row.get('Abstract', '')}"

# ---------------------- LLM 提取函数 ----------------------

def deepseek_extract(doc_text, api_client, max_retries=3, retry_delay=2):
    """
    调用 DeepSeek 提取关键词与因果对
    """

    prompt = (
    "You are a biomedical knowledge extraction expert. Please process the TEXT below in two steps:\n\n"
    "STEP 1: EXTRACT 15 KEYWORDS\n"
    "Based on the content of the text, extract exactly 15 most relevant English keywords or keyphrases that meet these criteria:\n"
    "- Each keyword is a biomedical term composed of 2–4 words\n"
    "- Precisely reflects core research elements (e.g., genes, proteins, diseases, biological processes)\n"
    "- Avoid generic terms like 'study', 'analysis', 'data', 'results'\n"
    "- Ensure conceptual independence and no redundancy between terms\n"
    "- The keywords should exhibit contextual associations with one another.\n"
    "- Normalize terminology (e.g., prefer 'IL-6' over 'Interleukin-6')\n"
    "- Sort strictly by importance in descending order\n"
    "- Format: semicolon-separated list without numbering or bullets\n"
    "- Output type: STRING, not array/list\n"
    "- Example output format: \"gene expression regulation; tumor microenvironment analysis\"\n\n"

    "STEP 2: IDENTIFY CAUSAL RELATIONSHIPS\n"
    "- From the extracted keywords and the original text context, identify at least ONE explicit OR inferred causal/mechanistic relationship.\n"
    "- Focus only on cause-effect links clearly stated OR logically implied from the text\n"
    "- Use natural language triplets that reflect the exact usage in the document\n"
    "- If no explicit link exists, infer based on biological mechanism or experimental evidence described\n"
    "- Return each relation as a JSON object with keys: 'cause', 'effect', 'relation'\n"
    "- Example: {\"cause\": \"TNF-alpha\", \"effect\": \"NF-kB activation\", \"relation\": \"induces\"}\n\n"

    "Return your final answer strictly in this JSON structure:\n"
    "{\n"
    "  \"keywords\": \"keyword1; keyword2; ...\",\n"
    "  \"causal_relations\": [\n"
    "    {\n"
    "      \"cause\": \"string\",\n"
    "      \"effect\": \"string\",\n"
    "      \"relation\": \"string\"\n"
    "    }\n"
    "  ]\n"
    "}\n"
    f"TEXT:\n{doc_text}"
    )

    for attempt in range(max_retries):
        try:
            response = api_client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {"role": "system", "content": "You are a biomedical knowledge extraction expert"},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
                max_tokens=2048,
                stream=False
            )
            content = response.choices[0].message.content.strip()

            # 提取 JSON 片段（如果响应中包含非 JSON 内容）
            start_idx = content.find("{")
            end_idx = content.rfind("}")
            if start_idx != -1 and end_idx != -1:
                content = content[start_idx:end_idx + 1]

            data = json.loads(content)
            logger.info(f"LLM 返回结果: {data}")

            # 清洗关键词
            raw_keywords = data.get("keywords", "")
            cleaned_keywords = clean_keywords(raw_keywords)

            # 安全提取因果对并过滤无效项
            causal_relations = []
            valid_keywords_set = set(cleaned_keywords)
            for item in data.get("causal_relations", []):
                cause = str(item.get("cause", "")).lower().strip()
                effect = str(item.get("effect", "")).lower().strip()
                relation = str(item.get("relation", "")).lower().strip()
                if cause in valid_keywords_set and effect in valid_keywords_set and relation:
                    causal_relations.append({
                        "cause": cause,
                        "effect": effect,
                        "relation": relation
                    })

            return {
                "keywords": cleaned_keywords,
                "causal_relations": causal_relations
            }

        except json.JSONDecodeError as je:
            logger.error(f"[JSON 解析失败] 内容: {content}")
        except Exception as e:
            logger.warning(f"[尝试 {attempt + 1}/{max_retries}] 请求失败: {e}")
            time.sleep(retry_delay)

    logger.error("多次请求失败或返回非 JSON 格式，返回空结果")
    return {"keywords": [], "causal_relations": []}


# ---------------------- 辅助函数：关键词清洗 ----------------------
'''
def clean_keywords(raw_keywords):
    if isinstance(raw_keywords, str):
        parts = raw_keywords.split(";")
    elif isinstance(raw_keywords, list):
        parts = [item.strip() for item in raw_keywords if isinstance(item, str)]
    else:
        return []

    cleaned = []
    for part in parts:
        part = part.strip().lower()
        if len(part) >= 3 and not re.match(r'^[^\w]+$', part):
            cleaned.append(part)

    return list(dict.fromkeys(cleaned))[:15]
'''
def clean_keywords(raw_keywords):
    # 处理输入格式
    if isinstance(raw_keywords, str):
        parts = raw_keywords.split(";")
    elif isinstance(raw_keywords, list):
        parts = [str(kw).strip() for kw in raw_keywords]
    else:
        return []

    cleaned = []
    for part in parts:
        part = part.strip().lower()
        # 移除数字编号前缀（如 "1.", "2. "）
        part = re.sub(r"^\d+\.?\s*", "", part).strip()
        # 必须是 2~4 个英文单词组成的术语
        if 2 <= len(part.split()) <= 4:
            # 过滤掉全是非字母字符的情况（如 ";", "***"）
            if re.search(r'[a-zA-Z]', part):
                cleaned.append(part)

    # 去重 + 限制数量
    return list(dict.fromkeys(cleaned))[:15]
# ---------------------- 并行处理函数 ----------------------

def process_documents_parallel(doc_texts, client, max_workers=32):
    """多线程调用 LLM 提取关键词与因果对"""
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_idx = {
            executor.submit(deepseek_extract, doc_text, client): idx
            for idx, doc_text in enumerate(doc_texts)
        }
        for future in tqdm(future_to_idx, total=len(doc_texts), desc="提取关键词与因果关系"):
            try:
                result = future.result()
                results.append(result)
            except Exception as exc:
                logger.error(f"文档处理出错: {exc}")
                results.append({"keywords": [], "causal_relations": []})
    return results


# ---------------------- 主流程函数 ----------------------

def main():
    """主函数：端到端执行从输入到输出的过程"""
    # 1. 读取并清洗数据
    logger.info("开始加载和清洗数据...")
    df = pd.read_csv(INPUT_CSV_PATH, nrows=2000)
    df = clean_data(df)

    # 2. 构建文本列表
    logger.info("构建文献文本列表...")
    doc_texts = df.apply(extract_text, axis=1).tolist()

    # 3. 并行抽取关键词与因果对
    logger.info("开始调用模型提取关键词与因果关系...")
    results = process_documents_parallel(doc_texts, client)

    # 4. 合并回原始 DataFrame 并构建 JSON 输出
    logger.info("将提取结果合并为 JSON 格式...")

    final_json = []
    for i, result in enumerate(results):
        # 只保留包含因果关系的条目
        if result.get("causal_relations"):  # ✅ 这里判断 causal_relations 是否非空
            entry = {
                "PMID": int(df.iloc[i]["PMID"]),
                "Title": df.iloc[i]["Title"],
                "Abstract": df.iloc[i]["Abstract"],
                "keywords": result.get("keywords", []),
                "causal_relations": result.get("causal_relations", [])
            }
            final_json.append(entry)

    # 5. 写入 JSON 文件（使用自定义 encoder）
    logger.info(f"写入 JSON 文件至 {OUTPUT_JSON_PATH}...")
    with open(OUTPUT_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(final_json, f, ensure_ascii=False, indent=2, cls=NpEncoder)

    logger.info(f"✅ 因果提取任务完成！结果已保存至：{OUTPUT_JSON_PATH}")


# ---------------------- 程序入口 ----------------------

if __name__ == "__main__":
    main()