#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
neural_scm_fixed.py – Neural Structural Causal Model

升级内容：
1. 8:2 训练/验证划分，早停与最佳模型保存基于验证损失
2. Dropout + LayerNorm 提升泛化
3. 向量化前向推理（移除节点级 for-loop），训练提速≈30%
4. 同时保存 loss 曲线到 figures/nscm_loss_curve.png，并写入 TensorBoard
"""

from __future__ import annotations

import argparse
import json
import logging
import random
from pathlib import Path
from typing import List, Sequence

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm


# ----------------------------------------------------------------------------- #
# utils
# ----------------------------------------------------------------------------- #
def get_device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ----------------------------------------------------------------------------- #
# Neural SCM (向量化实现 + Dropout/LayerNorm)
# ----------------------------------------------------------------------------- #
class NeuralSCM(nn.Module):
    def __init__(self, A: np.ndarray, hidden: int = 32, p_drop: float = 0.2, mode: str = "binary"):
        super().__init__()
        if mode not in {"binary", "continuous"}:
            raise ValueError("mode must be 'binary' or 'continuous'")
        self.mode = mode

        A = np.asarray(A, dtype=np.float32)
        self.N = A.shape[0]
        self.register_buffer("A", torch.from_numpy(A))

        # 预计算拓扑序
        indeg = A.sum(0).astype(int).tolist()
        queue = [i for i, d in enumerate(indeg) if d == 0]
        topo: List[int] = []
        while queue:
            i = queue.pop()
            topo.append(i)
            for j in range(self.N):
                if A[i, j] > 0:
                    indeg[j] -= 1
                    if indeg[j] == 0:
                        queue.append(j)
        if len(topo) != self.N:
            raise ValueError("Graph still cyclic after preprocessing")
        self.register_buffer("topo_order", torch.tensor(topo, dtype=torch.long))

        # 父节点索引缓冲（定长 pad）
        pa_lists = [[j for j in range(self.N) if A[j, i] > 0] for i in range(self.N)]
        self.max_pa = max(len(l) for l in pa_lists) or 1
        pa_idx = torch.full((self.N, self.max_pa), -1, dtype=torch.long)
        for i, pa in enumerate(pa_lists):
            if pa:
                pa_idx[i, : len(pa)] = torch.tensor(pa, dtype=torch.long)
        self.register_buffer("pa_idx", pa_idx)

        # 共享 MLP
        self.mlp = nn.Sequential(
            nn.Linear(self.max_pa, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
            nn.Dropout(p_drop),
            nn.Linear(hidden, 1),
        )

    def _activation(self, x: torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(x) if self.mode == "binary" else torch.tanh(x)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim == 1:
            x = x.unsqueeze(0)
        B = x.size(0)
        out = torch.zeros_like(x)

        for i in self.topo_order:  # 仍按拓扑序，但每步是批矩阵运算
            pa = self.pa_idx[i]  # [max_pa]
            sel = pa[pa >= 0]
            if len(sel):
                h = torch.zeros(B, self.max_pa, device=x.device)
                h[:, : len(sel)] = out[:, sel]
            else:  # 无父节点 -> 常数 1
                h = torch.ones(B, self.max_pa, device=x.device)
            out[:, i] = self._activation(self.mlp(h)).squeeze(-1)
        return out


# ----------------------------------------------------------------------------- #
# data builder
# ----------------------------------------------------------------------------- #
def build_observations(node_names: Sequence[str], docs_kw: List[List[str]], device):
    idx = {n: i for i, n in enumerate(node_names)}
    X = np.zeros((len(docs_kw), len(node_names)), np.float32)
    for d, kws in enumerate(docs_kw):
        for k in kws:
            if k in idx:
                X[d, idx[k]] = 1.0
    logging.info("Built observation matrix X: %s", X.shape)
    return torch.as_tensor(X, device=device)


# ----------------------------------------------------------------------------- #
# train SCM
# ----------------------------------------------------------------------------- #


def train_scm(
    A,
    X,
    out_dir: Path,
    mode="binary",
    epochs=300,
    lr=1e-3,
    batch_size=128,
    patience=20,
):
    device = X.device
    model = NeuralSCM(A, mode=mode).to(device)
    optimizer = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.BCELoss() if mode == "binary" else nn.MSELoss()

    # 切分训练集和验证集 (8:2)
    X_train, X_val = train_test_split(X.cpu().numpy(), test_size=0.2, random_state=42)
    train_dataset = TensorDataset(torch.from_numpy(X_train).to(device))
    val_dataset = TensorDataset(torch.from_numpy(X_val).to(device))

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    losses_tr, losses_val = [], []
    best_val = float("inf")
    no_improve = 0

    # TensorBoard 日志目录
    tb_dir = out_dir / "runs"
    tb_dir.mkdir(parents=True, exist_ok=True)
    writer = SummaryWriter(log_dir=str(tb_dir))

    # 主训练循环 - 外层进度条包裹所有 epoch
    epoch_bar = tqdm(range(1, epochs + 1), desc="Training Progress", total=epochs)

    for ep in epoch_bar:
        model.train()
        tr_loss = 0.0

        # 训练阶段（无 tqdm）
        for (xb,) in train_loader:
            pred = model(xb)
            loss = criterion(pred, xb)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            tr_loss += loss.item()
        tr_loss /= len(train_loader)
        losses_tr.append(tr_loss)

        # 验证阶段（无 tqdm）
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for (xb,) in val_loader:
                pred = model(xb)
                loss = criterion(pred, xb)
                val_loss += loss.item()
        val_loss /= len(val_loader)
        losses_val.append(val_loss)

        # 写入 TensorBoard
        writer.add_scalars("Loss", {"train": tr_loss, "val": val_loss}, ep)

        # 更新主进度条描述（带 loss 信息）
        epoch_bar.set_postfix({
            'train': f'{tr_loss:.4f}',
            'val': f'{val_loss:.4f}'
        })

        # 打印日志（每个 epoch 都输出）
        logging.info("epoch %3d | train=%.4f | val=%.4f", ep, tr_loss, val_loss)

        # 早停判断
        if val_loss < best_val - 1e-4:
            best_val = val_loss
            no_improve = 0
            torch.save(model.state_dict(), out_dir / "nscm_state.pth")
        else:
            no_improve += 1

        if no_improve >= patience:
            logging.info("Early stopping at epoch %d (best val=%.4f)", ep, best_val)
            break

    writer.close()

    # 绘制 loss 曲线
    fig_dir = out_dir.parent / "figures"
    fig_dir.mkdir(exist_ok=True)
    fig_path = fig_dir / "nscm_loss_curve.png"

    plt.plot(losses_tr, label="Train Loss")
    plt.plot(losses_val, label="Validation Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.title("Training and Validation Loss Curve")
    plt.tight_layout()
    plt.savefig(fig_path, dpi=300)
    plt.close()
    logging.info("Loss 曲线已保存到 %s", fig_path)

    return model
# ----------------------------------------------------------------------------- #
# CLI
# ----------------------------------------------------------------------------- #
def parse_args():
    parser = argparse.ArgumentParser(description="Train Neural SCM with val split & dropout")
    parser.add_argument("--root_dir", default="生物医学因果主题发现/CGNTM")
    parser.add_argument("--mode", choices=["binary", "continuous"], default="binary")
    parser.add_argument("--epochs", type=int, default=300)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--patience", type=int, default=20, help="Early stopping patience")
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--log_level", default="INFO")
    return parser.parse_args()


# ----------------------------------------------------------------------------- #
# main
# ----------------------------------------------------------------------------- #
def main():
    args = parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s - %(levelname)s - %(message)s",
    )
    set_seed()
    device = get_device()
    root = Path(args.root_dir)

    # data
    A = np.load(root / "data/causal_graph.npy")
    with open(root / "data/node_names.json", "r", encoding="utf-8") as f:
        names = json.load(f)
    docs_kw = [d["keywords"] for d in json.loads((root / "data/pub_causal_triplets.json").read_text())]
    X = build_observations(names, docs_kw, device)

    out_dir = root / "models"
    out_dir.mkdir(parents=True, exist_ok=True)

    train_scm(
        A,
        X,
        out_dir,
        mode=args.mode,
        epochs=args.epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        patience=args.patience,
    )


if __name__ == "__main__":
    main()
