#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
train.py – Joint training: NeuralSCM ⇆ WGAN ⇆ HierarchicalGNN
"""

from __future__ import annotations
import argparse, json, random, os, gc
from pathlib import Path
from typing import List, Tuple

import numpy as np
import torch, torch.nn as nn, torch.optim as optim
from tqdm.auto import tqdm

from neural_scm       import NeuralSCM, build_observations
from wgan_generator   import WGANGenerator
from discriminator    import WGANDiscriminator
from hierarchical_gnn import HierarchicalGNN
from consistency_loss import bert_consistency


# ------------------------------ utils ------------------------------ #
def seed_all(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark     = False


def get_dev(use_gpu: bool) -> torch.device:
    return torch.device("cuda" if use_gpu and torch.cuda.is_available() else "cpu")


# --------------------------- data / models ------------------------- #
def load_keywords(trip_file: Path) -> List[List[str]]:
    docs = json.load(open(trip_file, encoding="utf-8"))
    kws  = [d.get("keywords", []) for d in docs]
    return [[w.replace(" ", "_") for w in doc] for doc in kws]


def prepare(root: Path, device: torch.device) -> Tuple:
    data_dir = root / "data"

    # ----- graph -----
    A      = np.load(data_dir / "causal_graph.npy")
    names  = json.load(open(data_dir / "node_names.json", encoding="utf-8"))
    vocab  = ["<PAD>", "<BOS>", "<EOS>"] + [w.replace(" ", "_") for w in names]

    # ----- observations -----
    p_obs  = root / "models/observed.pt"
    if not p_obs.exists():
        docs_kw = load_keywords(data_dir / "pub_causal_triplets.json")
        X       = build_observations(names, docs_kw, device)
        p_obs.parent.mkdir(parents=True, exist_ok=True)
        torch.save(X.cpu(), p_obs)
    else:
        X = torch.load(p_obs).to(device)

    # ----- Neural SCM -----
    scm   = NeuralSCM(A).to(device)
    p_scm = root / "models/nscm_state.pth"
    if p_scm.exists():
        scm.load_state_dict(torch.load(p_scm, map_location=device))
        print("✓ pretrained SCM loaded.")

    # ----- latent cache -----
    p_lat = root / "models/latent.pt"
    if p_lat.exists():
        latent = torch.load(p_lat, map_location=device).to(device)
    else:
        latent = scm(X).detach()
        torch.save(latent.cpu(), p_lat)

    # ----- WGAN -----
    emb_dim = hid = 128
    G = WGANGenerator(len(vocab), latent.size(1), emb_dim=emb_dim,
                      hid=hid, share_emb_out=True).to(device)
    D = WGANDiscriminator(emb_dim=emb_dim).to(device)

    # ----- Hierarchical GNN (cluster 可选) -----
    cluster_path = data_dir / "cluster_ids.npy"
    cluster = np.load(cluster_path) if cluster_path.exists() else None
    hgnn = HierarchicalGNN(A, cluster=cluster, in_dim=1, hid=64,
                           device=device).to(device)

    # ----- 保存关键路径 -----
    eval_dir = root / "eval"; eval_dir.mkdir(exist_ok=True)
    return X, vocab, scm, G, D, hgnn, latent, eval_dir


# ------------------------- helper funcs ---------------------------- #
def decode(tok: torch.Tensor, vocab: List[str]) -> List[str]:
    sents = []
    for row in tok:
        words = []
        for idx in row.tolist():
            if idx == 0:               # <PAD>
                continue
            if idx == 2:               # <EOS>
                break
            words.append(vocab[idx])
        sents.append(" ".join(words))
    return sents


def grad_penalty(D, real, fake):
    eps   = torch.rand(real.size(0), 1, 1, device=real.device)
    inter = eps * real + (1 - eps) * fake
    inter.requires_grad_()
    score = D(inter, torch.full((inter.size(0),), inter.size(1),
                                dtype=torch.long, device=inter.device))
    grad  = torch.autograd.grad(score.sum(), inter, create_graph=True)[0]
    return grad.view(grad.size(0), -1).norm(2, dim=1).pow(2).mean()


def sample_real_tokens(keywords: List[List[str]],
                       vocab: List[str],
                       batch: int,
                       max_len: int,
                       device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
    """从抽取的 keywords 随机拼句，替代纯随机 token"""
    word2idx = {w: i for i, w in enumerate(vocab)}
    tok = torch.zeros(batch, max_len, dtype=torch.long, device=device)
    lengths = torch.zeros(batch, dtype=torch.long, device=device)

    for i in range(batch):
        kw = random.choice(keywords)[:max_len]
        kw = ["<BOS>"] + kw + ["<EOS>"]
        kw_idx = [word2idx.get(w, 0) for w in kw][:max_len]
        tok[i, :len(kw_idx)] = torch.tensor(kw_idx, device=device)
        lengths[i] = len(kw_idx)
    return tok, lengths


# ------------------------------ train ------------------------------ #
def train_joint(root: Path, use_gpu: bool):
    device = get_dev(use_gpu)
    (X, vocab, scm, G, D, hgnn,
     latent, eval_dir) = prepare(root, device)

    # ------------------ optim ------------------ #
    opt_D = optim.Adam(D.parameters(), 2e-4)
    opt_G = optim.Adam(G.parameters(), 1e-4)
    opt_S = optim.Adam(scm.parameters(), 3e-3)
    opt_H = optim.Adam(hgnn.parameters(), 1e-3)

    λ_cons, λ_scm, λ_gp = 0.1, 0.05, 20.0
    k_D, k_G            = 1, 1
    n_scm, n_hgnn       = 20, 500
    total_steps         = 1500
    batch               = 32
    max_len             = 8
    tau_start, tau_end  = 1.0, 0.3
    n_eval_export       = 300          # 导出 BERT 嵌入频率

    # keywords cache
    keywords = load_keywords(root / "data" / "pub_causal_triplets.json")

    # containers for CSA eval
    embed_real, embed_cf = [], []

    for step in tqdm(range(total_steps)):
        tau = max(tau_end, tau_start - (tau_start - tau_end) * step / total_steps)

        # ===== 1) Discriminator =====
        for _ in range(k_D):
            idx = torch.randint(0, latent.size(0), (batch,), device=device)
            z   = latent[idx]

            real_tok, real_len = sample_real_tokens(keywords, vocab, batch,
                                                    max_len, device)
            fake_tok, fake_len = G(z, max_len, tau=tau)

            real_emb = G.emb(real_tok)
            fake_emb = G.emb(fake_tok).detach()

            d_real = D(real_emb, real_len).mean()
            d_fake = D(fake_emb, fake_len).mean()
            gp     = grad_penalty(D, real_emb, fake_emb)

            opt_D.zero_grad()
            (d_fake - d_real + λ_gp * gp).backward()
            opt_D.step()

        # ===== 2) Generator =====
        idx  = torch.randint(0, latent.size(0), (batch,), device=device)
        z    = latent[idx]
        fake_tok, fake_len = G(z, max_len, tau=tau)
        fake_emb           = G.emb(fake_tok)
        loss_adv           = -D(fake_emb, fake_len).mean()

        # BERT consistency
        sentences_real = decode(real_tok, vocab)
        sentences_fake = decode(fake_tok, vocab)
        loss_cons      = bert_consistency(list(zip(sentences_real, sentences_fake)),
                                          device=device, reduction="mean")

        z_pred   = scm(X)
        loss_scm = nn.BCELoss()(z_pred, X)

        opt_G.zero_grad()
        (loss_adv + λ_cons * loss_cons + λ_scm * loss_scm).backward()
        opt_G.step()

        # ===== 3) SCM 更新 =====
        if step % n_scm == 0:
            z_pred = scm(X)
            loss_S = nn.BCELoss()(z_pred, X)
            opt_S.zero_grad(); loss_S.backward(); opt_S.step()

        # ===== 4) HGNN 更新 =====
        if step % n_hgnn == 0 and step:
            noise  = torch.randn_like(latent) * 0.05
            out    = hgnn((latent + noise).unsqueeze(-1))
            loss_H = nn.MSELoss()(out, out.detach())
            opt_H.zero_grad(); loss_H.backward(); opt_H.step()

        # ===== 5) 每 n_eval_export 步导出嵌入 =====
        if step % n_eval_export == 0:
            with torch.no_grad():
                enc = bert_consistency.encoder
                embed_real.append(enc(sentences_real).cpu())
                embed_cf.append(enc(sentences_fake).cpu())

        if step % 200 == 0:
            print(f"[{step:4d}] D_adv {d_fake.item()-d_real.item():+.3f} "
                  f"G_adv {loss_adv.item():+.3f} Cons {loss_cons.item():.3f} "
                  f"τ {tau:.2f}")

        if step and step % 500 == 0:
            (root / "models").mkdir(exist_ok=True)
            torch.save(G.state_dict(), root / "models" / f"g_step{step}.pth")
            torch.save(D.state_dict(), root / "models" / f"d_step{step}.pth")
            gc.collect(); torch.cuda.empty_cache()

    # ---------------- save final models ---------------- #
    md = root / "models"; md.mkdir(exist_ok=True)
    torch.save(scm.state_dict(),  md / "scm_joint.pth")
    torch.save(G.state_dict(),    md / "g_joint.pth")
    torch.save(D.state_dict(),    md / "d_joint.pth")
    torch.save(hgnn.state_dict(), md / "hgnn_joint.pth")
    print("✓ All models saved to", md)

    # ---------------- save embeddings for CSA ---------------- #
    if embed_real and embed_cf:
        orig = torch.cat(embed_real).numpy()
        cf   = torch.cat(embed_cf).numpy()
        np.savez(eval_dir / "embeddings.npz", orig=orig, cf=cf)
        print("✓ embeddings.npz saved for CSA evaluation.")


# ------------------------------ CLI ------------------------------ #
def cli():
    p = argparse.ArgumentParser("Joint causal training (with optional clustering)")
    p.add_argument("--root_dir", default="生物医学因果主题发现/CGNTM")
    p.add_argument("--gpu", action="store_true")
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


if __name__ == "__main__":
    args = cli()
    seed_all(args.seed)
    train_joint(Path(args.root_dir), args.gpu)
