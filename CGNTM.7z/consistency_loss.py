#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
consistency_loss.py – Semantic-consistency distance with SciBERT

改动亮点
--------
1. 单例缓存 + 动态设备迁移
2. CUDA 环境自动启用混合精度 (amp)
3. 可批量处理句对，支持 "mean"/"sum"/"none"
"""
from __future__ import annotations
from typing import Sequence, Tuple, Iterable

import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel

# ----------------------- global cache ----------------------- #
_TOKENIZER = None
_BERT      = None
_DEVICE    = None


# ----------------------- helper ----------------------------- #
def get_scibert(device: str | torch.device | None = None):
    """返回 (tokenizer, model, device)。若已缓存则复用。"""
    global _TOKENIZER, _BERT, _DEVICE
    device = torch.device(
        device if device is not None else ("cuda" if torch.cuda.is_available() else "cpu")
    )

    if _TOKENIZER is None:
        name = "allenai/scibert_scivocab_uncased"
        _TOKENIZER = AutoTokenizer.from_pretrained(name)
        _BERT = AutoModel.from_pretrained(name)      # 先落在 CPU
        _DEVICE = torch.device("cpu")

    if _DEVICE != device:
        _BERT = _BERT.to(device, non_blocking=True)
        _DEVICE = device
    return _TOKENIZER, _BERT, _DEVICE


# ----------------------- main API --------------------------- #
def bert_consistency(
    pairs: Sequence[Tuple[str, str]] | Tuple[str, str],
    device: str | torch.device | None = None,
    reduction: str = "mean",
) -> torch.Tensor:
    """Compute 1-cosine similarity for each (src, tgt) pair.

    Parameters
    ----------
    pairs : (src, tgt) or list/tuple of such pairs
    device : target device; default "cuda" if available
    reduction : "mean" | "sum" | "none"
    """
    # -------- normalize input --------
    if isinstance(pairs[0], str):                 # type: ignore[index]
        pairs = [pairs]                           # 单条 → 列表
    src, tgt = zip(*pairs)                        # type: ignore[arg-type]
    tok, bert, dev = get_scibert(device)

    enc = tok(list(src) + list(tgt),
              padding=True, truncation=True, return_tensors="pt").to(dev)

    n = len(src)
    with torch.inference_mode(), (
        torch.cuda.amp.autocast() if dev.type == "cuda" else torch._C.DisableTorchFunction()
    ):
        cls = bert(**enc).last_hidden_state[:, 0]  # (2n,768)

    v1, v2 = cls[:n], cls[n:]
    dist = 1.0 - F.cosine_similarity(v1, v2)      # (n,)

    if reduction == "mean":
        return dist.mean()
    if reduction == "sum":
        return dist.sum()
    if reduction != "none":
        raise ValueError("reduction must be 'mean'|'sum'|'none'")
    return dist  # shape (n,)
