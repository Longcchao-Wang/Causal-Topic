#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
discriminator.py – Wasserstein GAN critic for generated text.

v1.2 2025-05-30
---------------
* spectral_norm via torch.nn.utils
* 自动推断 lengths（当 pad=0 时）
* Dropout & 代码风格统一
"""
from __future__ import annotations
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import spectral_norm


class WGANDiscriminator(nn.Module):
    r"""BiLSTM (可选) + mean/last pooling → Linear score."""

    def __init__(
        self,
        emb_dim: int,
        hid: int = 512,
        bidirectional: bool = True,
        use_last: bool = False,
        dropout: float = 0.3,
    ) -> None:
        """
        Parameters
        ----------
        emb_dim : int
            输入嵌入维度 F。
        hid : int
            LSTM 隐藏大小。
        bidirectional : bool, default True
            是否使用双向 LSTM。
        use_last : bool, default False
            若 True 则用最后隐藏态池化，否则 mean-pool。
        dropout : float
            线性层前的 Dropout。
        """
        super().__init__()
        self.use_last = use_last
        self.lstm = nn.LSTM(
            emb_dim,
            hid,
            batch_first=True,
            bidirectional=bidirectional,
        )
        out_dim = hid * (2 if bidirectional else 1)
        self.layer_norm = nn.LayerNorm(out_dim)
        self.drop = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.fc = spectral_norm(nn.Linear(out_dim, 1))

    # ------------------------------------------------------------------ #
    def _infer_lengths(self, seq: torch.Tensor) -> torch.Tensor:
        """推断每条样本的有效长度 (pad==0)。"""
        mask = (seq.abs().sum(-1) != 0)  # (B,L)
        return mask.long().sum(1)        # (B,)

    def forward(
        self,
        emb_seq: torch.Tensor,                  # (B,L,F)
        lengths: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:                          # (B,)
        if lengths is None:
            lengths = self._infer_lengths(emb_seq).cpu()

        # ------- pack padded -------
        packed = nn.utils.rnn.pack_padded_sequence(
            emb_seq, lengths.cpu(), batch_first=True, enforce_sorted=False
        )
        packed_out, (h_n, _) = self.lstm(packed)

        if self.use_last:
            feat = h_n.transpose(0, 1).reshape(emb_seq.size(0), -1)  # concat last hidden(s)
        else:
            out, _ = nn.utils.rnn.pad_packed_sequence(packed_out, batch_first=True)
            L = out.size(1)
            mask = (
                torch.arange(L, device=out.device)[None, :] < lengths.to(out.device)[:, None]
            )
            feat = (out * mask.unsqueeze(-1)).sum(1) / lengths.to(out).unsqueeze(1)

        feat = self.drop(self.layer_norm(feat))
        return self.fc(feat).squeeze(-1)
