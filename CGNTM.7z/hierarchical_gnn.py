from __future__ import annotations
from typing import Union
import numpy as np
import torch
import torch.nn as nn
from causal_gnn import CausalGNN

class HierarchicalGNN(nn.Module):
    r"""Base-level CausalGNN + Cluster-level CausalGNN"""

    def __init__(
        self,
        A_base: Union[torch.Tensor, np.ndarray],
        in_dim: int,
        cluster: torch.Tensor | list[int] = None,  # Make cluster parameter optional
        hid: int | None = None,
        base_L: int = 2,
        abs_L: int = 1,
        device: str | torch.device | None = None,
    ) -> None:
        super().__init__()

        device = (
            torch.device(device)
            if device is not None
            else torch.device("cuda" if torch.cuda.is_available() else "cpu")
        )

        # If cluster is not provided, use a default (empty) cluster assignment
        if cluster is None:
            cluster = torch.zeros(A_base.shape[0], dtype=torch.long, device=device)  # Default to empty cluster (all zeros)

        self.cluster = cluster
        self.K: int = int(cluster.max().item()) + 1  # num clusters

        # ---------- base level ----------
        hid = hid or in_dim
        self.base = CausalGNN(A_base, in_dim, hid, base_L, device=device)
        hid = self.base.in_proj.out_features  # actual hidden dim

        # ---------- build abstract adjacency ----------
        Ab = torch.as_tensor(A_base, dtype=torch.float32, device=device)
        idx_i, idx_j = Ab.nonzero(as_tuple=True)
        Abs = torch.zeros(self.K, self.K, device=device)
        ci, cj = cluster[idx_i], cluster[idx_j]  # parent→child mapping
        Abs.index_put_((ci, cj), Ab[idx_i, idx_j], accumulate=True)

        if Abs.sum() == 0:  # safeguard
            Abs += torch.eye(self.K, device=device) * 1e-6

        self.abs = CausalGNN(Abs, hid, hid, abs_L, device=device)

        # ---------- fusion ----------
        self.fuse = nn.Linear(2 * hid, hid, bias=False)
        self.act = nn.ReLU()

    # ------------------------------------------------------------------ #
    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B?, N, F)
        batchless = x.dim() == 2
        if batchless:
            x = x.unsqueeze(0)

        # ---- base encoding ----
        h = self.base(x)  # (B,N,H)

        # ---- aggregate node → cluster ----
        B, N, H = h.shape
        cl = self.cluster
        cl_exp = cl.unsqueeze(0).expand(B, -1)  # (B,N)
        abs_h = torch.zeros(B, self.K, H, device=h.device)
        abs_h.scatter_add_(1, cl_exp.unsqueeze(-1).expand(-1, -1, H), h)

        counts = torch.bincount(cl, minlength=self.K).clamp_min(1).float().to(h.device)
        abs_h /= counts.view(1, -1, 1)  # mean pooling

        # ---- abstract propagation ----
        abs_h = self.abs(abs_h)  # (B,K,H)

        # ---- broadcast cluster ctx back to nodes ----
        ctx = abs_h.gather(1, cl_exp.unsqueeze(-1).expand(-1, -1, H))  # (B,N,H)
        out = self.act(self.fuse(torch.cat([h, ctx], dim=-1)))
        return out.squeeze(0) if batchless else out
